import { Component } from '@angular/core';

@Component({
	selector: 'first-app',
	// template: 'abc',
	templateUrl: 'template/app.template.html',
	styles: [``],
	styleUrls: [`template/app.style.css`]
})

export class AppComponent { }
